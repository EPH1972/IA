import pyamaze as maze
from queue import PriorityQueue

ROWS = 20
COLS = 20

# def distance(cell1, cell2):
    

# def aStar(m):
#    return forwardPath

m=maze.maze(ROWS,COLS)
m.CreateMaze()
pre_Astar = time.time()
path = aStar(m)
post_Astar = time.time()
print(post_Astar - pre_Astar)
a=maze.agent(m,footprints=True)
m.tracePath({a:path},delay=5)
m.run()
